#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse, os

TMPL = r"""-- Auto-generated Dyck (GHC parallel baseline)
import Control.DeepSeq (NFData(..), force)
import Control.Parallel.Strategies (parTuple2, rdeepseq, using)

-- Parameters (compile-time)
n0     :: Int
n0     = __N__
p0     :: Int
p0     = __P__
imb0   :: Int
imb0   = __IMB__
delta0 :: Int
delta0 = __DELTA__

-- Utilities
repeatDyck :: Int -> [Int] -> [Int]
repeatDyck m acc = if m == 0 then acc else repeatDyck (m - 1) (1 : (-1) : acc)

generateDyck :: Int -> Int -> [Int]
generateDyck len d =
  let base = repeatDyck (len `div` 2) [] in
  if d == 0 then base
  else if d > 0 then base ++ replicate d 1
  else base ++ replicate (abs d) (-1)

append :: [a] -> [a] -> [a]
append [] ys     = ys
append (h:t) ys  = h : append t ys

len :: [a] -> Int
len []     = 0
len (_:xs) = 1 + len xs

takeN :: Int -> [a] -> [a]
takeN k _  | k <= 0 = []
takeN _ []          = []
takeN k (y:ys)      = y : takeN (k-1) ys

dropN :: Int -> [a] -> [a]
dropN k xs | k <= 0 = xs
dropN _ []          = []
dropN k (_:ys)      = dropN (k-1) ys

splitAtN :: Int -> [a] -> ([a],[a])
splitAtN k xs = (takeN k xs, dropN k xs)

-- analyseChunk (sum, min-prefix)
analyseChunk :: [Int] -> (Int, Int)
analyseChunk = go 0 0
  where
    go s mn []     = (s, mn)
    go s mn (x:xs) = let s1  = s + x
                         mn1 = if s1 < mn then s1 else mn
                     in go s1 mn1 xs

chunkPair :: [Int] -> (Int, Int)
chunkPair = analyseChunk

-- Work-skewed split with clamping: 1 <= k <= n-1
splitImb :: [a] -> ([a],[a])
splitImb xs =
  let n    = len xs
      kRaw = (n * (100 + imb0)) `div` 200
      k    = if n <= 1 then 1 else max 1 (min (n-1) kRaw)
  in splitAtN k xs

threshold :: Int
threshold = n0 `div` p0

checkRec :: [Int] -> (Int, Int)
checkRec lst
  | len lst <= threshold = chunkPair lst
  | otherwise =
      let (lft, rgt) = splitImb lst
          -- parallel evaluation of both halves
          (lr, rr) = (checkRec lft, checkRec rgt) `using` parTuple2 rdeepseq rdeepseq
          (s1,m1) = lr
          (s2,m2) = rr
      in ( s1 + s2
         , let v = s1 + m2 in if m1 < v then m1 else v )

validateDyck :: [Int] -> Bool
validateDyck xs = let (tot, mn) = checkRec xs in (tot == 0) && (mn >= 0)

main :: IO ()
main = do
  let inputSeq = generateDyck n0 delta0
  let ok = validateDyck inputSeq
  ok `seq` putStrLn (if ok then "OK" else "BAD")
"""

def emit_hs(out, N, P, IMB, DELTA, vec_kind):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    src = (TMPL
           .replace("__N__", str(N))
           .replace("__P__", str(P))
           .replace("__IMB__", str(IMB))
           .replace("__DELTA__", str(DELTA)))
    with open(out, "w", encoding="utf-8") as f:
        f.write(src)
    print(f"[hs_gen_input] wrote {out} (N={N}, P={P}, imb={IMB}, delta={DELTA})")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--N", type=int, required=True)
    ap.add_argument("--P", type=int, required=True)
    ap.add_argument("--imb", type=int, required=True)
    ap.add_argument("--delta", type=int, required=True)
    ap.add_argument("--vec", default="range", choices=["range","rand"])
    args = ap.parse_args()
    emit_hs(args.out, args.N, args.P, args.imb, args.delta, args.vec)

if __name__ == "__main__":
    main()
